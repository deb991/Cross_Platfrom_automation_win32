# AzureNotify
PowerShell scripts to use with Azure Automation to send notifications by SMS/Mail/and-so-on
