from MailSend.MailSendClass import MailSendClass

# SendMail Test
MailSendClass.sendmain(object)